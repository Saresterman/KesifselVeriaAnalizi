install.packages("MASS")
library(MASS)

#Verinin olusturuldugu kisim
set.seed(123)
n<-100 #Gozlem degeri
x1<-rnorm(n,mean=15, sd=4) #Bagimsiz degisken 1
x2<-rnorm(n,mean=8, sd=1.5) #Bagimsiz degisken 2
x3<-rnorm(n,mean=4, sd=0.9) #Bagimsiz degisken 3 
x4<-rnorm(n,mean=3, sd=2) #Bagimsiz degisken 4
x5<-rnorm(n,mean=10,sd=2) #Bagimsiz degisken 5

y <- 2 + 3*x1 + 0.2*x2 - 1.3*x3 + 1.5*x4 + 0.5*x5 + rnorm(n,mean = 0, sd=2) #Bağımlı değişken


data<-data.frame(y,x1,x2,x3,x4,x5) #Olusturulan datayı veri çerçevesine dönüştürme

#Olusturulan veri setini gosterma (ilk 6 satiri verir)
head(data)

#Kesifsel Veri Analizinde yer alan verinin aktarım ve dönüşümü
set.seed(123)
n<-100
x1_f <- rnorm (n,mean = 15 , sd=4)
x2_f <- rnorm (n,mean = 8, sd = 1.5)
y_f <- rnorm (n, mean = 2 + 3*x1 + 0.2*x2 ,sd=2) #Yeniden isimlendirmemizin nedeni : Burada eğer isimleri değiştirmeseydik daha önceden oluşturduğumuz değişkenlerin yerine geçerdi. Bu nedenle isimlendirme farklı yapılmıştır.

# x1 değişkeninin faktörel değişkene dönüştürülmesi
x1_f_factor <- as.factor(x1_f)

# x2 değişkeninin nümerik bir değişkene dönüştürülmesi
x2_f_numeric <- as.numeric(x2_f)

# Değişken türlerinin kontrolü
str(x1_f_factor)
str(x2_f_numeric)

#Keşifsel veri analizinde yer alan veri kalitesi adımı
#Veri setini oluşturalım #Yeniden isimlendirelim
set.seed(123)
n<-100
x1_vk <- rnorm(n,mean=15,sd=4)
x2_vk <-rnorm(n,mean=8,sd=1.5)
y_vk <- rnorm(n,mean=2 + 3*x1 + 0.2*x2 ,sd=2)

#Eksik verilerin tespitini yapalım
is_na_x1<- is.na(x1_vk) #Mantıksal sonuç vermesini isteriz. view(is_na_x1) komutu ile birlikte değerlerin "False" olduğunu görürüz. Bunun nedeni zaten veri tarafımızca doldurulduğu için eksik veri bulunmamaktadır. Eğer eksik veri bulunsaydı "True" olarak karşımıza çıkacaktı.
is_na_x2<- is.na(x2_vk)

#Eksik veri olmadığı için verinin doldurulmasına gerek yok. Eğer olsaydı ortalama ile veya locf ile doldurabilirdik.
#locf için bir örnek yapacak olursak ;
install.packages("zoo")
library(zoo)
vec <- c(2, 4, NA, 8, NA)
#locf yöntemi ile eksik NA değerlerini doldurma
vec_filled <- na.locf(vec)
print(vec_filled)

#NA var ise eksik değerleri en yakın değerle doldurma
#Yine örnek bir vektör oluşturalım. Kendi verimizde eksik veri olmadığını biliyoruz.
install.packages("zoo")
library(zoo)
vec2 <- c(2, 4, NA, 8, NA)
vec_filled2 <- na.locf(vec)
print(vec_filled2)

#Aykırı değerlerin tespiti
set.seed(123)
data<-rnorm(100)

# Box-plot oluşturalım
boxplot(data) #İncelendiğinde aykırı olabilecek değerler gözlemlenir.
sort(data)

mean(data)

#Z puanını hehsaplayalım
z_skoru <-scale(data)

#Aykırı değerleri belirleyelim
aykiri_deger <- abs(z_skoru) > 3
sort(z_skoru)
sort(data) #Verinin ortalaması ne kadar "0" olarak dursada 0 olmadığı için verilerin biraz saptığı görülmektedir. 

#Çeyrekliklerin hesabı
Ceyrek1 <- quantile(data,0.25)
Ceyrek3 <- quantile(data,0.75)

#Sınırları belirleme
IQR <- Ceyrek1-Ceyrek3
Alt_sinir <- Ceyrek1 - 1.5*IQR
Ust_sinir <- Ceyrek3 + 1.5*IQR

#Aykırı değerlerin belirlenmesi
Aykiridegerler <- data < Alt_sinir | data > Ust_sinir

#Keşifsel veri analizinde dağılımların keşfi
hist(data) #Histogram Grafiği
qqnorm(data) #Q-Q Plot
qqline(data)

#Veri seti
set.seed(123)
x <- rnorm(100)
y<- 2*x + rnorm(100,mean = 0, sd= 0.5)

korelasyon <- cor(x,y) #Korelasyon katsayısı hesaplama
print(korelasyon) #Korelasyon katsayılarını yazdırma

#Çoklu regresyon modeli
motivasyon <- rnorm(100)
calisma_orani<-rnorm(100)
calisma_ortami <- rnorm(100)
basari <- 3*motivasyon + 4*calisma_orani + 1.5*calisma_ortami + rnorm(100, mean= 0, sd =0.5)

#Çoklu regresyon 
regresyon_modeli<- lm(y~motivasyon+calisma_orani+calisma_ortami)

#Oluşturulan çoklu regresyon modelinin özeti
summary(regresyon_modeli)

#Korelasyon matrisi
korelasyon_matrisi <- cor(data.frame(motivasyon,calisma_orani,calisma_ortami))
print(korelasyon_matrisi)

#Görselleştirme
library(corrplot)
corrplot(korelasyon_matrisi,method = "color")

#Veriyi standartlaştırma
motivasyon_s <-scale(motivasyon)
calisma_orani_s <- scale(calisma_orani)
calisma_ortami_s <- scale(calisma_ortami)
basari_s <- scale(basari)

#Kontrol
summary(motivasyon_s)
summary(calisma_orani_s)
summary(calisma_ortami_s)
summary(basari_s)

#veriyi test ve bölme
install.packages("caTools")
library(caTools)
split <- sample.split(basari, SplitRatio = 0.7)
train_data <-subset(data.frame(motivasyon,calisma_ortami,calisma_orani,basari),split==TRUE)
test_data <- subset (data.frame (motivasyon,calisma_orani,calisma_ortami,basari),split ==FALSE)

#Veri boyutu
dim(train_data)
dim(test_data)